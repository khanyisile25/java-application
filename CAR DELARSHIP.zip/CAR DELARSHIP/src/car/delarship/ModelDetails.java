/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package car.delarship;

/**
 *
 * @author makhanyi
 */
public class ModelDetails {
    String ModelDetails="Five seat, All wheel drive standard,Standard mild hybreed system";
    public static void main(String[]args){
    ModelDetails myobj=new ModelDetails();
    System.out.println(myobj.ModelDetails);
    
    }
}
